export const AppConfig = {
  site_name: 'defiOS',
  title: 'defiOS',
  description: 'defying open source, making free software sustainable for all',
  locale: 'en',
};
