"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/[...nextauth]";
exports.ids = ["pages/api/auth/[...nextauth]"];
exports.modules = {

/***/ "next-auth":
/*!****************************!*\
  !*** external "next-auth" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ "next-auth/providers/github":
/*!*********************************************!*\
  !*** external "next-auth/providers/github" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/github");

/***/ }),

/***/ "(api)/./src/pages/api/auth/[...nextauth].tsx":
/*!**********************************************!*\
  !*** ./src/pages/api/auth/[...nextauth].tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ \"next-auth\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/github */ \"next-auth/providers/github\");\n/* harmony import */ var next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1__);\n\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_0___default()({\n    secret: process.env.NEXTAUTH_SECRET,\n    // Configure one or more authentication providers\n    providers: [\n        next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1___default()({\n            clientId: process.env.GITHUB_CLIENT_ID || \"\",\n            clientSecret: process.env.GITHUB_CLIENT_SECRET || \"\",\n            authorization: {\n                params: {\n                    // I wish to request additional permission scopes.\n                    scope: \"repo read:user user:email\"\n                }\n            }\n        })\n    ],\n    theme: {\n        colorScheme: \"dark\",\n        brandColor: \"#FFFFFF\",\n        logo: \"https://res.cloudinary.com/rohitkk432/image/upload/v1660833498/defios_logo_gsg4eo.png\",\n        buttonText: \"Sign in with Github\"\n    },\n    callbacks: {\n        async jwt ({ token , account  }) {\n            // Persist the OAuth access_token to the token right after signin\n            if (account) {\n                token.accessToken = account.access_token;\n            }\n            return token;\n        },\n        async session ({ session , token  }) {\n            // Send properties to the client, like an access_token from a provider.\n            session.accessToken = token.accessToken;\n            return session;\n        }\n    }\n}));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvcGFnZXMvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBa0M7QUFDc0I7QUFFeEQsaUVBQWVBLGdEQUFRLENBQUM7SUFDcEJFLE1BQU0sRUFBRUMsT0FBTyxDQUFDQyxHQUFHLENBQUNDLGVBQWU7SUFDbkMsaURBQWlEO0lBQ2pEQyxTQUFTLEVBQUU7UUFDUEwsaUVBQWMsQ0FBQztZQUNYTSxRQUFRLEVBQUVKLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSSxnQkFBZ0IsSUFBSSxFQUFFO1lBQzVDQyxZQUFZLEVBQUVOLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDTSxvQkFBb0IsSUFBRyxFQUFFO1lBQ25EQyxhQUFhLEVBQUU7Z0JBQ1hDLE1BQU0sRUFBRTtvQkFDSixrREFBa0Q7b0JBQ2xEQyxLQUFLLEVBQUUsMkJBQTJCO2lCQUNyQzthQUNKO1NBQ0osQ0FBQztLQUVMO0lBQ0RDLEtBQUssRUFBRTtRQUNIQyxXQUFXLEVBQUUsTUFBTTtRQUNuQkMsVUFBVSxFQUFFLFNBQVM7UUFDckJDLElBQUksRUFBRSx1RkFBdUY7UUFDN0ZDLFVBQVUsRUFBQyxxQkFBcUI7S0FDbkM7SUFDREMsU0FBUyxFQUFFO1FBQ1AsTUFBTUMsR0FBRyxFQUFDLEVBQUVDLEtBQUssR0FBRUMsT0FBTyxHQUFFLEVBQUU7WUFDMUIsaUVBQWlFO1lBQ2pFLElBQUlBLE9BQU8sRUFBRTtnQkFDVEQsS0FBSyxDQUFDRSxXQUFXLEdBQUdELE9BQU8sQ0FBQ0UsWUFBWTtZQUM1QyxDQUFDO1lBQ0QsT0FBT0gsS0FBSztRQUNoQixDQUFDO1FBQ0QsTUFBTUksT0FBTyxFQUFDLEVBQUVBLE9BQU8sR0FBRUosS0FBSyxHQUU3QixFQUFFO1lBQ0MsdUVBQXVFO1lBQ3ZFSSxPQUFPLENBQUNGLFdBQVcsR0FBR0YsS0FBSyxDQUFDRSxXQUFXO1lBQ3ZDLE9BQU9FLE9BQU87UUFDbEIsQ0FBQztLQUNKO0NBQ0osQ0FBQyxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vREVGSU9TTEFORElORy8uL3NyYy9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLnRzeD9lYTJhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBOZXh0QXV0aCAgZnJvbSBcIm5leHQtYXV0aFwiO1xyXG5pbXBvcnQgR2l0aHViUHJvdmlkZXIgZnJvbSBcIm5leHQtYXV0aC9wcm92aWRlcnMvZ2l0aHViXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOZXh0QXV0aCh7XHJcbiAgICBzZWNyZXQ6IHByb2Nlc3MuZW52Lk5FWFRBVVRIX1NFQ1JFVCxcclxuICAgIC8vIENvbmZpZ3VyZSBvbmUgb3IgbW9yZSBhdXRoZW50aWNhdGlvbiBwcm92aWRlcnNcclxuICAgIHByb3ZpZGVyczogW1xyXG4gICAgICAgIEdpdGh1YlByb3ZpZGVyKHtcclxuICAgICAgICAgICAgY2xpZW50SWQ6IHByb2Nlc3MuZW52LkdJVEhVQl9DTElFTlRfSUQgfHwgJycsXHJcbiAgICAgICAgICAgIGNsaWVudFNlY3JldDogcHJvY2Vzcy5lbnYuR0lUSFVCX0NMSUVOVF9TRUNSRVR8fCAnJyxcclxuICAgICAgICAgICAgYXV0aG9yaXphdGlvbjoge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gSSB3aXNoIHRvIHJlcXVlc3QgYWRkaXRpb25hbCBwZXJtaXNzaW9uIHNjb3Blcy5cclxuICAgICAgICAgICAgICAgICAgICBzY29wZTogJ3JlcG8gcmVhZDp1c2VyIHVzZXI6ZW1haWwnLFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLy8gQWRkIG90aGVyIHByb3ZpZGVycyBoZXJlXHJcbiAgICBdLFxyXG4gICAgdGhlbWU6IHtcclxuICAgICAgICBjb2xvclNjaGVtZTogXCJkYXJrXCIsIC8vIFwiYXV0b1wiIHwgXCJkYXJrXCIgfCBcImxpZ2h0XCJcclxuICAgICAgICBicmFuZENvbG9yOiBcIiNGRkZGRkZcIiwgLy8gSGV4IGNvbG9yIGNvZGVcclxuICAgICAgICBsb2dvOiBcImh0dHBzOi8vcmVzLmNsb3VkaW5hcnkuY29tL3JvaGl0a2s0MzIvaW1hZ2UvdXBsb2FkL3YxNjYwODMzNDk4L2RlZmlvc19sb2dvX2dzZzRlby5wbmdcIiwgLy8gQWJzb2x1dGUgVVJMIHRvIGltYWdlXHJcbiAgICAgICAgYnV0dG9uVGV4dDpcIlNpZ24gaW4gd2l0aCBHaXRodWJcIiwgLy8gVGV4dCB0byBkaXNwbGF5IG9uIHRoZSBzaWduIGluIGJ1dHRvblxyXG4gICAgfSxcclxuICAgIGNhbGxiYWNrczoge1xyXG4gICAgICAgIGFzeW5jIGp3dCh7IHRva2VuLCBhY2NvdW50IH0pIHtcclxuICAgICAgICAgICAgLy8gUGVyc2lzdCB0aGUgT0F1dGggYWNjZXNzX3Rva2VuIHRvIHRoZSB0b2tlbiByaWdodCBhZnRlciBzaWduaW5cclxuICAgICAgICAgICAgaWYgKGFjY291bnQpIHtcclxuICAgICAgICAgICAgICAgIHRva2VuLmFjY2Vzc1Rva2VuID0gYWNjb3VudC5hY2Nlc3NfdG9rZW5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdG9rZW5cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIHNlc3Npb24oeyBzZXNzaW9uLCB0b2tlbiwgXHJcbiAgICAgICAgICAgIC8vIHVzZXJcclxuICAgICAgICB9KSB7XHJcbiAgICAgICAgICAgIC8vIFNlbmQgcHJvcGVydGllcyB0byB0aGUgY2xpZW50LCBsaWtlIGFuIGFjY2Vzc190b2tlbiBmcm9tIGEgcHJvdmlkZXIuXHJcbiAgICAgICAgICAgIHNlc3Npb24uYWNjZXNzVG9rZW4gPSB0b2tlbi5hY2Nlc3NUb2tlblxyXG4gICAgICAgICAgICByZXR1cm4gc2Vzc2lvblxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSk7XHJcbiJdLCJuYW1lcyI6WyJOZXh0QXV0aCIsIkdpdGh1YlByb3ZpZGVyIiwic2VjcmV0IiwicHJvY2VzcyIsImVudiIsIk5FWFRBVVRIX1NFQ1JFVCIsInByb3ZpZGVycyIsImNsaWVudElkIiwiR0lUSFVCX0NMSUVOVF9JRCIsImNsaWVudFNlY3JldCIsIkdJVEhVQl9DTElFTlRfU0VDUkVUIiwiYXV0aG9yaXphdGlvbiIsInBhcmFtcyIsInNjb3BlIiwidGhlbWUiLCJjb2xvclNjaGVtZSIsImJyYW5kQ29sb3IiLCJsb2dvIiwiYnV0dG9uVGV4dCIsImNhbGxiYWNrcyIsImp3dCIsInRva2VuIiwiYWNjb3VudCIsImFjY2Vzc1Rva2VuIiwiYWNjZXNzX3Rva2VuIiwic2Vzc2lvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./src/pages/api/auth/[...nextauth].tsx\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./src/pages/api/auth/[...nextauth].tsx"));
module.exports = __webpack_exports__;

})();